/****************************************************************************
 *  This class manages an N-by-N hex game board .
 ****************************************************************************/

public class HexBoard {
    public HexBoard(int N) {
    }

    public int getPlayer(int row, int col) {
        return 0;
    }
    
    public boolean isSet(int row, int col) {
        return false;
    }

    public boolean isOnWinningPath(int row, int col) {
        return false;
    }

    public void setTile(int row, int col, int player) {
    }

    public boolean hasPlayer1Won() {
        return false;
    }

    public boolean hasPlayer2Won() {
        return false;
    }

    public int numberOfUnsetTiles() {
        return 0;
    }
}
